# Widget Minicart

Storefront plugin with Vue component for shopping cart quickview E-Com Plus stores
